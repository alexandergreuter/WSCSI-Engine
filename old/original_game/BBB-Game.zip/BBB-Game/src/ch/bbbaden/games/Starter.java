/*
 */
package ch.bbbaden.games;

/**
 *
 * @author Michael Schneider (michael.schneider@bbbaden.ch)
 */
public class Starter {

    public static void main(String[] args) {
       new LibBasicsEvents().run();
    }
}
